package com.example.gallery   // change to your own package name

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    // Android 13+ uses READ_MEDIA_IMAGES, older versions use READ_EXTERNAL_STORAGE
    private val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

    // Real system permission dialog; result is sent back to the page
    private val ask = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        web.evaluateJavascript("window.onGalleryPermission($ok)", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidGallery")

        // Serves https://gallery.local/thumb/<id> and /full/<id> straight from the device's MediaStore
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                if (u.host != "gallery.local") return null
                val id = u.lastPathSegment?.toLongOrNull() ?: return null
                val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                return try {
                    if (u.path.orEmpty().startsWith("/thumb/")) {
                        val bmp = contentResolver.loadThumbnail(uri, Size(320, 320), null)
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        WebResourceResponse("image/jpeg", null, ByteArrayInputStream(out.toByteArray()))
                    } else {
                        WebResourceResponse(contentResolver.getType(uri), null, contentResolver.openInputStream(uri))
                    }
                } catch (e: Exception) { null }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean =
            ContextCompat.checkSelfPermission(this@MainActivity, perm) == PackageManager.PERMISSION_GRANTED

        @JavascriptInterface
        fun requestPermission() { runOnUiThread { ask.launch(perm) } }

        @JavascriptInterface
        fun getPhotos(): String {
            val arr = JSONArray()
            val cols = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED
            )
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    arr.put(JSONObject()
                        .put("id", c.getLong(0))
                        .put("name", c.getString(1))
                        .put("album", c.getString(2) ?: "Other")
                        .put("date", c.getLong(3)))
                }
            }
            return arr.toString()
        }
    }
}
